#!/usr/bin/env python3
"""
P4CCI Topology — Mininet emulation for the P4CCI baseline.
Uses P4Switch from the behavioral-model source in the P4 Tutorial VM.

All hosts are on a single /24 subnet (10.0.0.0/24) to avoid any
cross-subnet routing complications. The P4 switch forwards based on
destination IP using LPM table entries.
"""

import sys
import os
from time import sleep

# Use the p4_mininet from the P4 tutorial utils (available in the P4 dev VM)
sys.path.insert(0, '/home/p4/tutorials/utils')
sys.path.insert(0, '/home/p4/src/behavioral-model/mininet')
sys.path.insert(0, '/home/p4/src/mininet')

from mininet.net import Mininet
from mininet.topo import Topo
from mininet.log import setLogLevel, info
from mininet.cli import CLI
from mininet.link import TCLink
from p4_mininet import P4Switch, P4Host


class P4CCITopo(Topo):
    """
    Topology:
        h1 (CUBIC sender) ──┐
                             ├── [s1: P4Switch] ──┬── h3 (Receiver 1)
        h2 (BBR sender)   ──┘                     └── h4 (Receiver 2)
    All hosts on 10.0.0.0/24. The bottleneck is s1→h3/h4 links (1 Gbps).
    """

    def __init__(self, sw_path, json_path, thrift_port=9090, **opts):
        Topo.__init__(self, **opts)

        # Programmable P4 switch (BMv2 simple_switch)
        s1 = self.addSwitch('s1',
                            sw_path=sw_path,
                            json_path=json_path,
                            thrift_port=thrift_port,
                            pcap_dump=False)

        # All hosts on same /24 subnet — eliminates routing issues
        h1 = self.addHost('h1', ip='10.0.0.1/24', mac='00:00:00:00:00:01')
        h2 = self.addHost('h2', ip='10.0.0.2/24', mac='00:00:00:00:00:02')
        h3 = self.addHost('h3', ip='10.0.0.3/24', mac='00:00:00:00:00:03')
        h4 = self.addHost('h4', ip='10.0.0.4/24', mac='00:00:00:00:00:04')

        # Sender → Switch (access links, no rate limit)
        self.addLink(h1, s1, delay='5ms')
        self.addLink(h2, s1, delay='5ms')

        # Switch → Receivers (bottleneck links at 1 Gbps, 200-pkt buffer)
        self.addLink(s1, h3, bw=1000, delay='10ms', max_queue_size=200)
        self.addLink(s1, h4, bw=1000, delay='10ms', max_queue_size=200)


def populate_arp(net):
    """
    Statically populate ARP caches on all hosts.
    Since P4 switch doesn't handle ARP, each host needs to know
    every other host's MAC address.
    """
    h1, h2, h3, h4 = net.get('h1', 'h2', 'h3', 'h4')

    arp_table = {
        '10.0.0.1': '00:00:00:00:00:01',
        '10.0.0.2': '00:00:00:00:00:02',
        '10.0.0.3': '00:00:00:00:00:03',
        '10.0.0.4': '00:00:00:00:00:04',
    }
    for host in [h1, h2, h3, h4]:
        for ip, mac in arp_table.items():
            host.cmd(f'arp -s {ip} {mac}')


def set_cca(host, algo):
    """Sets TCP congestion control algorithm for a host."""
    host.cmd(f'sysctl -w net.ipv4.tcp_congestion_control={algo}')
    result = host.cmd('sysctl net.ipv4.tcp_congestion_control')
    info(f'[CCA] {host.name}: {result.strip()}\n')


def populate_switch_tables(thrift_port=9090):
    """
    Pushes L3 forwarding rules to the P4 switch via simple_switch_CLI.
    Port mapping (based on Mininet link order):
        Port 1: h1,  Port 2: h2,  Port 3: h3,  Port 4: h4
    """
    info('*** Populating P4 switch tables\n')
    rules = [
        'table_add ipv4_lpm ipv4_forward 10.0.0.1/32 => 00:00:00:00:00:01 1',
        'table_add ipv4_lpm ipv4_forward 10.0.0.2/32 => 00:00:00:00:00:02 2',
        'table_add ipv4_lpm ipv4_forward 10.0.0.3/32 => 00:00:00:00:00:03 3',
        'table_add ipv4_lpm ipv4_forward 10.0.0.4/32 => 00:00:00:00:00:04 4',
    ]
    cli_input = '\n'.join(rules) + '\n'
    cmd = f'echo "{cli_input}" | simple_switch_CLI --thrift-port {thrift_port}'
    os.system(cmd)


def run_automated_traffic(net):
    """
    Start automated iperf3 CUBIC vs BBR traffic experiment.
    - h1 → h3 : CUBIC (starts at t=0)
    - h2 → h4 : BBR   (starts at t=15s to show throughput collapse)
    Both run for 60 seconds total.
    """
    h1, h2, h3, h4 = net.get('h1', 'h2', 'h3', 'h4')

    # Set CCAs
    set_cca(h1, 'cubic')
    set_cca(h2, 'bbr')

    # TCP send/receive buffers as used in the paper (200 MB)
    for h in [h1, h2, h3, h4]:
        h.cmd('sysctl -w net.core.rmem_max=209715200')
        h.cmd('sysctl -w net.core.wmem_max=209715200')
        h.cmd('sysctl -w net.ipv4.tcp_rmem="4096 87380 209715200"')
        h.cmd('sysctl -w net.ipv4.tcp_wmem="4096 65536 209715200"')

    info('*** Starting iperf3 servers on h3 and h4\n')
    h3.cmd('iperf3 -s -p 5001 -D')
    h4.cmd('iperf3 -s -p 5002 -D')
    sleep(2)

    # Verify servers are listening
    info('*** Verifying iperf3 servers\n')
    print(h3.cmd('ss -tlnp | grep 5001'))
    print(h4.cmd('ss -tlnp | grep 5002'))

    info('*** Starting CUBIC flow: h1 → h3 (port 5001)\n')
    h1.cmd('iperf3 -c 10.0.0.3 -p 5001 -t 60 -i 5 > /tmp/cubic_flow.log 2>&1 &')

    sleep(15)
    info('*** Starting BBR flow: h2 → h4 (port 5002) — 15s after CUBIC\n')
    h2.cmd('iperf3 -c 10.0.0.4 -p 5002 -t 45 -i 5 > /tmp/bbr_flow.log 2>&1 &')

    info('*** Traffic running. Waiting 65s for flows to complete...\n')
    sleep(65)

    info('\n=== CUBIC Flow Results ===\n')
    print(h1.cmd('cat /tmp/cubic_flow.log'))
    info('\n=== BBR Flow Results ===\n')
    print(h2.cmd('cat /tmp/bbr_flow.log'))


def main():
    sw_path  = 'simple_switch'
    json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'build', 'p4cci_switch.json')

    if not os.path.exists(json_path):
        print(f'[ERROR] Compiled JSON not found: {json_path}')
        print('Run: p4c --target bmv2 --arch v1model p4cci_switch.p4 -o build/')
        sys.exit(1)

    topo = P4CCITopo(sw_path=sw_path, json_path=json_path)

    net = Mininet(topo=topo,
                  host=P4Host,
                  switch=P4Switch,
                  link=TCLink,
                  controller=None)

    net.start()
    populate_arp(net)
    sleep(2)
    populate_switch_tables()
    sleep(1)

    info('\n*** Testing connectivity (ping)\n')
    net.pingAll()

    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--auto', action='store_true',
                        help='Run automated CUBIC vs BBR traffic experiment')
    args, _ = parser.parse_known_args()

    if args.auto:
        run_automated_traffic(net)
    else:
        info('\n*** Dropping into Mininet CLI. Type "exit" to quit.\n')
        info('    Run traffic manually: e.g., h1 iperf3 -c 10.0.0.3 -p 5001 -t 60\n\n')
        CLI(net)

    net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    main()
