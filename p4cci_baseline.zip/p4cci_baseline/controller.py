#!/usr/bin/env python3
"""
P4CCI Controller — Control-plane logic for the P4CCI baseline.
Uses pure Python stdlib (no numpy/torch) for maximum portability on the P4 dev VM.

Pipeline:
  1. Collect per-flow BIF time-series from P4 digest (simulated here).
  2. Apply MAD-based outlier rejection (Robust Z-score).
  3. Apply Z-normalization.
  4. Classify via threshold heuristic (CUBIC=high variance, BBR=low variance).
  5. Push ACL rule to P4 switch via simple_switch_CLI.
"""

import sys
import os
import math
import subprocess
from collections import defaultdict

SEQ_LENGTH    = 50     # BIF samples needed before classification
MAD_THRESHOLD = 3.5    # Robust Z-score cutoff (from paper)
THRIFT_PORT   = 9090
SWITCH_CMD    = 'simple_switch_CLI'

# Per-flow BIF sample buffer: {(src_ip, dst_ip, src_port, dst_port): [bif...]}
flow_bif_buffer = defaultdict(list)


# ---------------------------------------------------------------------------
# Pure-Python math helpers (replaces numpy)
# ---------------------------------------------------------------------------

def _median(data):
    """Return median of a list of numbers."""
    s = sorted(data)
    n = len(s)
    mid = n // 2
    return s[mid] if n % 2 != 0 else (s[mid - 1] + s[mid]) / 2.0


def _mean(data):
    return sum(data) / len(data)


def _std(data):
    mu = _mean(data)
    variance = sum((x - mu) ** 2 for x in data) / len(data)
    return math.sqrt(variance)


# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------

def mad_outlier_rejection(time_series):
    """
    Robust Z-score outlier rejection using Median Absolute Deviation (MAD).
    Formula: M_i = 0.6745 * (x_i - x̂) / MAD ; reject where |M_i| > 3.5
    """
    if len(time_series) < 2:
        return time_series[:]

    median = _median(time_series)
    mad    = _median([abs(x - median) for x in time_series])

    if mad == 0:
        return time_series[:]

    filtered = [x for x in time_series
                if abs(0.6745 * (x - median) / mad) <= MAD_THRESHOLD]
    return filtered if filtered else time_series[:]


def z_normalization(time_series):
    """Z-score normalization: x' = (x - μ) / σ"""
    mu    = _mean(time_series)
    sigma = _std(time_series)
    if sigma == 0:
        return [0.0] * len(time_series)
    return [(x - mu) / sigma for x in time_series]


def pad_or_truncate(ts, length, fill_val=0.0):
    """Pad with fill_val or truncate to exactly `length` samples."""
    if len(ts) < length:
        ts = ts + [fill_val] * (length - len(ts))
    return ts[:length]


# ---------------------------------------------------------------------------
# Classification (threshold heuristic)
# ---------------------------------------------------------------------------

def threshold_classify(ts_normalized):
    """
    Statistical CCA classifier (no ML dependency).

    Intuition from the paper:
    - CUBIC (loss-based): sawtooth window growth → high variance BIF, positive mean.
    - BBR (model-based): pacing → near-constant BIF → low variance, near-zero mean.

    Empirical thresholds (tune based on observed traffic):
      std > 0.8 OR mean > 0.4  →  Loss-based (CUBIC/Reno)
      else                      →  Model-based (BBR)
    """
    sigma = _std(ts_normalized)
    mu    = _mean(ts_normalized)
    if sigma > 0.8 or mu > 0.4:
        return 0   # Loss-based
    return 1       # Model-based


def classify_flow(flow_key, raw_bif):
    """Full preprocessing + classification pipeline."""
    # Step 1: Outlier rejection
    ts_clean = mad_outlier_rejection(raw_bif)

    # Step 2: Pad / truncate
    fill = _median(ts_clean) if ts_clean else 0.0
    ts_fixed = pad_or_truncate(ts_clean, SEQ_LENGTH, fill_val=fill)

    # Step 3: Z-normalization
    ts_norm = z_normalization(ts_fixed)

    # Step 4: Classify
    pred   = threshold_classify(ts_norm)
    label  = "CUBIC/Reno (Loss-based)" if pred == 0 else "BBR (Model-based)"
    sigma  = _std(ts_norm)
    mu     = _mean(ts_norm)
    print(f"[+] Flow {flow_key}")
    print(f"    Samples: {len(raw_bif)}  |  σ={sigma:.4f}  |  μ={mu:.4f}")
    print(f"    Classified as: {label}")
    return pred


# ---------------------------------------------------------------------------
# Switch Rule Insertion
# ---------------------------------------------------------------------------

def insert_switch_rule(flow_key, prediction, thrift_port=THRIFT_PORT):
    """
    Pushes an ACL table entry to the P4 switch via simple_switch_CLI.
    cca_class: 1 = Loss-based (CUBIC/Reno), 2 = Model-based (BBR)
    """
    src_ip, dst_ip, src_port, dst_port = flow_key
    class_id = 1 if prediction == 0 else 2

    cli_cmd = (
        f"table_add cca_classification set_cca_class "
        f"{src_ip} {dst_ip} {src_port} {dst_port} => {class_id}"
    )
    print(f"[*] Inserting rule: {cli_cmd}")

    try:
        proc = subprocess.Popen(
            [SWITCH_CMD, '--thrift-port', str(thrift_port)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        stdout, stderr = proc.communicate(
            input=(cli_cmd + '\n').encode(), timeout=5
        )
        if stdout.strip():
            print(f"    CLI: {stdout.decode().strip()}")
    except FileNotFoundError:
        print(f"[!] {SWITCH_CMD} not found — rule not pushed (switch may not be running).")
    except subprocess.TimeoutExpired:
        print("[!] simple_switch_CLI timed out.")
    except Exception as e:
        print(f"[!] CLI error: {e}")


# ---------------------------------------------------------------------------
# BIF digest ingestion
# ---------------------------------------------------------------------------

def process_digest(digest_data):
    """
    Called for each BIF digest from the P4 switch.
    digest_data = (flow_id, bif, src_ip, dst_ip, src_port, dst_port)
    """
    _, bif, src_ip, dst_ip, src_port, dst_port = digest_data
    flow_key = (src_ip, dst_ip, src_port, dst_port)
    flow_bif_buffer[flow_key].append(float(bif))

    count = len(flow_bif_buffer[flow_key])
    if count % 10 == 0:
        print(f"    Collecting: {flow_key} — {count}/{SEQ_LENGTH} samples")

    if count == SEQ_LENGTH:
        pred = classify_flow(flow_key, flow_bif_buffer[flow_key])
        insert_switch_rule(flow_key, pred)
        flow_bif_buffer[flow_key] = []   # reset for re-classification


# ---------------------------------------------------------------------------
# Synthetic self-test (no switch required)
# ---------------------------------------------------------------------------

def simulate_bif_stream(flow_key, pattern='cubic', seed=42):
    """
    Generates synthetic BIF samples to validate the pipeline end-to-end.
    'cubic' → sawtooth (high σ),  'bbr' → paced (low σ)
    """
    import random
    rng = random.Random(seed)

    print(f"\n{'='*60}")
    print(f"[SIM] Simulating {pattern.upper()} flow: {flow_key}")
    print(f"{'='*60}")

    bif_vals = []
    for i in range(SEQ_LENGTH):
        if pattern == 'cubic':
            # Sawtooth: ramp up in 20-sample windows, drop on loss
            ramp = (i % 20) + 1
            bif  = ramp * 1460 + rng.gauss(0, 500)
        else:
            # BBR: near-constant pacing
            bif = 8000 + rng.gauss(0, 200)
        bif_vals.append(bif)

    for bif in bif_vals:
        process_digest((0, bif, *flow_key))


if __name__ == '__main__':
    print("=" * 60)
    print("P4CCI Controller — Baseline Self-Test (Pure Python)")
    print("=" * 60)
    print(f"Python version: {sys.version}")
    print(f"No external dependencies required.\n")

    # Experiment 1: CUBIC-like flow
    cubic_flow = ('10.0.1.1', '10.0.2.1', 5001, 80)
    simulate_bif_stream(cubic_flow, pattern='cubic')

    # Experiment 2: BBR-like flow
    bbr_flow = ('10.0.1.2', '10.0.2.2', 5002, 80)
    simulate_bif_stream(bbr_flow, pattern='bbr')

    print("\n[+] Self-test complete.")
    print("    Expected: CUBIC→Loss-based, BBR→Model-based")
