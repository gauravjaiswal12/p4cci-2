import torch
import torch.nn as nn
import torch.nn.functional as F

class FCN(nn.Module):
    def __init__(self, num_classes=2, in_channels=1):
        """
        Implementation of the Fully Convolutional Network (FCN) described in P4CCI.
        - Kernels: {8, 5, 3}
        - Filters: {128, 256, 128}
        - Global Average Pooling
        - Softmax Output
        """
        super(FCN, self).__init__()
        
        # Block 1
        self.conv1 = nn.Conv1d(in_channels=in_channels, out_channels=128, kernel_size=8, padding='same')
        self.bn1 = nn.BatchNorm1d(num_features=128)
        
        # Block 2
        self.conv2 = nn.Conv1d(in_channels=128, out_channels=256, kernel_size=5, padding='same')
        self.bn2 = nn.BatchNorm1d(num_features=256)
        
        # Block 3
        self.conv3 = nn.Conv1d(in_channels=256, out_channels=128, kernel_size=3, padding='same')
        self.bn3 = nn.BatchNorm1d(num_features=128)
        
        # Output layer
        self.fc = nn.Linear(in_features=128, out_features=num_classes)
        
    def forward(self, x):
        # x expected shape: (batch_size, in_channels (1), sequence_length)
        
        # Block 1
        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)
        
        # Block 2
        x = self.conv2(x)
        x = self.bn2(x)
        x = F.relu(x)
        
        # Block 3
        x = self.conv3(x)
        x = self.bn3(x)
        x = F.relu(x)
        
        # Global Average Pooling (GAP)
        # Average across the sequence_length dimension
        x = torch.mean(x, dim=2)
        
        # Fully connected (Output layer)
        x = self.fc(x)
        
        return F.softmax(x, dim=1)

def build_model(num_classes=2):
    """
    Returns an instance of the FCN model.
    """
    return FCN(num_classes=num_classes)

if __name__ == "__main__":
    # Test block
    model = build_model()
    # Dummy input: batch_size=32, channels=1, sequence_length=50
    dummy_input = torch.randn(32, 1, 50)
    output = model(dummy_input)
    print("FCN Output shape:", output.shape) # Expected: (32, 2)
