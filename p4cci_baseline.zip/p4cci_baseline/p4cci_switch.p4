#include <core.p4>
#include <v1model.p4>

const bit<16> TYPE_IPV4 = 0x0800;
const bit<8>  TYPE_TCP  = 6;

// enq_qdepth is bit<19> in v1model — must match type
const bit<19> CONGESTION_THRESHOLD = 5;

/*************************************************************************
*********************** H E A D E R S  ***********************************
*************************************************************************/
typedef bit<9>  egressSpec_t;
typedef bit<48> macAddr_t;
typedef bit<32> ip4Addr_t;

header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

header ipv4_t {
    bit<4>    version;
    bit<4>    ihl;
    bit<8>    diffserv;
    bit<16>   totalLen;
    bit<16>   identification;
    bit<3>    flags;
    bit<13>   fragOffset;
    bit<8>    ttl;
    bit<8>    protocol;
    bit<16>   hdrChecksum;
    ip4Addr_t srcAddr;
    ip4Addr_t dstAddr;
}

header tcp_t {
    bit<16> srcPort;
    bit<16> dstPort;
    bit<32> seqNo;
    bit<32> ackNo;
    bit<4>  dataOffset;
    bit<3>  res;
    bit<3>  ecn;
    bit<6>  ctrl;
    bit<16> window;
    bit<16> checksum;
    bit<16> urgentPtr;
}

struct metadata_t {
    bit<32> flow_id;
    bit<32> bif;
    bit<32> last_ack;
    bit<8>  cca_class; // 0=short(default), 1=loss(CUBIC), 2=model(BBR)
    bit<1>  is_ack;
}

struct headers_t {
    ethernet_t ethernet;
    ipv4_t     ipv4;
    tcp_t      tcp;
}

// Struct for Digest sent to control plane
// In v1model, digest() takes a struct type as a type parameter
struct bif_digest_t {
    bit<32> flow_id;
    bit<32> bif;
    bit<32> srcAddr;
    bit<32> dstAddr;
    bit<16> srcPort;
    bit<16> dstPort;
}

/*************************************************************************
*********************** P A R S E R  *************************************
*************************************************************************/
parser MyParser(packet_in packet,
                out headers_t hdr,
                inout metadata_t meta,
                inout standard_metadata_t standard_metadata) {

    state start {
        transition parse_ethernet;
    }

    state parse_ethernet {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            TYPE_IPV4: parse_ipv4;
            default: accept;
        }
    }

    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition select(hdr.ipv4.protocol) {
            TYPE_TCP: parse_tcp;
            default: accept;
        }
    }

    state parse_tcp {
        packet.extract(hdr.tcp);
        transition accept;
    }
}

/*************************************************************************
************   C H E C K S U M    V E R I F I C A T I O N   *************
*************************************************************************/
control MyVerifyChecksum(inout headers_t hdr, inout metadata_t meta) {
    apply { }
}

/*************************************************************************
**************  I N G R E S S   P R O C E S S I N G   *******************
*************************************************************************/
control MyIngress(inout headers_t hdr,
                  inout metadata_t meta,
                  inout standard_metadata_t standard_metadata) {

    // Register array: stores last ACK per flow (indexed by 16-bit flow hash)
    register<bit<32>>(65536) last_ack_reg;

    action drop() {
        mark_to_drop(standard_metadata);
    }

    action ipv4_forward(macAddr_t dstAddr, egressSpec_t port) {
        standard_metadata.egress_spec = port;
        hdr.ethernet.srcAddr = hdr.ethernet.dstAddr;
        hdr.ethernet.dstAddr = dstAddr;
        hdr.ipv4.ttl = hdr.ipv4.ttl - 1;
    }

    action set_cca_class(bit<8> class_id) {
        meta.cca_class = class_id;
    }

    table ipv4_lpm {
        key = {
            hdr.ipv4.dstAddr: lpm;
        }
        actions = {
            ipv4_forward;
            drop;
            NoAction;
        }
        size = 1024;
        default_action = drop();
    }

    // Populated by Controller after CCA classification
    table cca_classification {
        key = {
            hdr.ipv4.srcAddr: exact;
            hdr.ipv4.dstAddr: exact;
            hdr.tcp.srcPort:  exact;
            hdr.tcp.dstPort:  exact;
        }
        actions = {
            set_cca_class;
            NoAction;
        }
        size = 8192;
        default_action = NoAction();
    }

    apply {
        if (hdr.ipv4.isValid()) {
            ipv4_lpm.apply();

            if (hdr.tcp.isValid()) {
                // Lookup existing CCA classification
                cca_classification.apply();

                // Compute 16-bit flow hash from 5-tuple
                hash(meta.flow_id,
                     HashAlgorithm.crc16,
                     (bit<32>)0,
                     { hdr.ipv4.srcAddr,
                       hdr.ipv4.dstAddr,
                       hdr.tcp.srcPort,
                       hdr.tcp.dstPort,
                       hdr.ipv4.protocol },
                     (bit<32>)65535);

                // Detect ACK bit (bit 4 of ctrl field = 0x10)
                bit<6> ack_mask = 0x10;
                if ((hdr.tcp.ctrl & ack_mask) != 0) {
                    meta.is_ack = 1;
                } else {
                    meta.is_ack = 0;
                }

                if (meta.is_ack == 1) {
                    // Update stored ACK for this flow
                    last_ack_reg.write(meta.flow_id, hdr.tcp.ackNo);
                }

                // Data packet: IPv4 header (20B) + TCP header (20B min) = 40B
                if (hdr.ipv4.totalLen > 40) {
                    // Read the last stored ACK
                    last_ack_reg.read(meta.last_ack, meta.flow_id);

                    // BIF = current SEQ - last seen ACK
                    meta.bif = hdr.tcp.seqNo - meta.last_ack;

                    // Only send digest during congestion
                    // enq_qdepth is bit<19> in v1model
                    if (standard_metadata.enq_qdepth > CONGESTION_THRESHOLD) {
                        // Send BIF sample to control plane
                        // digest() signature: digest<T>(bit<32> receiver, T data)
                        digest<bif_digest_t>(1, {
                            meta.flow_id,
                            meta.bif,
                            hdr.ipv4.srcAddr,
                            hdr.ipv4.dstAddr,
                            hdr.tcp.srcPort,
                            hdr.tcp.dstPort
                        });
                    }
                }
            }
        }
    }
}

/*************************************************************************
****************  E G R E S S   P R O C E S S I N G   *******************
*************************************************************************/
control MyEgress(inout headers_t hdr,
                 inout metadata_t meta,
                 inout standard_metadata_t standard_metadata) {
    apply {
        // meta.cca_class carries the queue assignment:
        //   0 = default (short flows)
        //   1 = Loss-based (CUBIC / Reno)
        //   2 = Model-based (BBR)
        // Actual queue steering via simple_switch priority queueing
        // is configured through controller CLI commands at runtime.
    }
}

/*************************************************************************
*************   C H E C K S U M    C O M P U T A T I O N   **************
*************************************************************************/
control MyComputeChecksum(inout headers_t hdr, inout metadata_t meta) {
    apply {
        update_checksum(
            hdr.ipv4.isValid(),
            { hdr.ipv4.version,
              hdr.ipv4.ihl,
              hdr.ipv4.diffserv,
              hdr.ipv4.totalLen,
              hdr.ipv4.identification,
              hdr.ipv4.flags,
              hdr.ipv4.fragOffset,
              hdr.ipv4.ttl,
              hdr.ipv4.protocol,
              hdr.ipv4.srcAddr,
              hdr.ipv4.dstAddr },
            hdr.ipv4.hdrChecksum,
            HashAlgorithm.csum16);
    }
}

/*************************************************************************
***********************  D E P A R S E R  ********************************
*************************************************************************/
control MyDeparser(packet_out packet, in headers_t hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.ipv4);
        packet.emit(hdr.tcp);
    }
}

/*************************************************************************
***********************  S W I T C H  ************************************
*************************************************************************/
V1Switch(
    MyParser(),
    MyVerifyChecksum(),
    MyIngress(),
    MyEgress(),
    MyComputeChecksum(),
    MyDeparser()
) main;
