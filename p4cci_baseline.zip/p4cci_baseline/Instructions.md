# P4CCI Baseline: Replication Instructions

Follow these steps to run the P4-based CCA Identification (P4CCI) baseline on a P4 Tutorial VM.

## 1. Prerequisites
Ensure you are using the standard **P4 Tutorials Development VM** (Ubuntu-based).

### Install Network Tools
The automated experiment requires `iperf3`. Run this inside your VM:
```bash
sudo apt-get update
sudo apt-get install -y iperf3
```

## 2. Setup the Workspace
1. Copy the `p4cci_baseline` folder to your VM's home directory (`~/`).
2. Navigate to the project directory:
   ```bash
   cd ~/p4cci_baseline
   ```

## 3. Compile the P4 Program
Generate the BMv2 JSON configuration for the switch:
```bash
# Create build directory if it doesn't exist
mkdir -p build

# Compile
p4c --target bmv2 --arch v1model p4cci_switch.p4 -o build/
```

## 4. Run the Automated Experiment
The experiment automatically creates a Mininet topology, sets up the P4 switch, and runs CUBIC vs. BBR traffic for 60 seconds.

### Clean up old state (Recommended)
Before running, ensure no old Mininet or Switch instances are hanging:
```bash
sudo mn -c
sudo killall simple_switch iperf3 2>/dev/null
```

### Start the Experiment
```bash
sudo python3 topology.py --auto
```

## 5. Viewing Results
Once the script finishes (approx. 80 seconds), it will print the `iperf3` logs to the terminal.

*   **CUBIC Result:** Check the "CUBIC Flow Results" section. You should see a high initial throughput that drops significantly once the BBR flow starts.
*   **BBR Result:** Check the "BBR Flow Results" section. You should see stable, paced throughput.
*   **Logs:** Raw logs are saved in `/tmp/cubic_flow.log` and `/tmp/bbr_flow.log`.

## 6. Project Components
*   `p4cci_switch.p4`: Data plane logic (BIF calculation, congestion alerts).
*   `controller.py`: Statistical classifier (identify CCA based on BIF variance).
*   `topology.py`: Mininet emulation script.
*   `report.md`: Detailed analysis of the baseline's findings.

---
**Note:** If you get a "ModuleNotFoundError: No module named 'mininet'", verify the paths at the top of `topology.py` (lines 12–14) match your VM's file structure.
